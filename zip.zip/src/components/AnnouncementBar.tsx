export default function AnnouncementBar() {
  return (
    <div className="bg-black text-white text-xs md:text-sm py-2 text-center font-medium tracking-wider uppercase">
      Free Delivery Available on all orders over $200
    </div>
  );
}
