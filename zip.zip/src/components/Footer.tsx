import { Link } from "react-router-dom";
import { Instagram, Facebook, Twitter, Mail, MapPin, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-black text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <h2 className="font-serif text-2xl font-bold tracking-widest mb-6">ZAHIYA</h2>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Elegance in every stitch. We bring you premium modest fashion that empowers and inspires confidence.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-gold-500 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold-500 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold-500 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-sans font-semibold uppercase tracking-wider text-sm mb-6">Quick Links</h3>
            <ul className="space-y-4">
              <li><Link to="/shop" className="text-gray-400 hover:text-white transition-colors text-sm">Shop All</Link></li>
              <li><Link to="/shop?category=Abayas" className="text-gray-400 hover:text-white transition-colors text-sm">Abayas</Link></li>
              <li><Link to="/shop?category=Modest Wear" className="text-gray-400 hover:text-white transition-colors text-sm">Modest Wear</Link></li>
              <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors text-sm">Our Story</Link></li>
            </ul>
          </div>

          {/* Customer Care */}
          <div>
            <h3 className="font-sans font-semibold uppercase tracking-wider text-sm mb-6">Customer Care</h3>
            <ul className="space-y-4">
              <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors text-sm">Contact Us</Link></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Shipping & Returns</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Size Guide</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">FAQ</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-sans font-semibold uppercase tracking-wider text-sm mb-6">Get in Touch</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-gray-400 text-sm">
                <MapPin className="w-5 h-5 flex-shrink-0 text-gold-500" />
                <span>123 Fashion Avenue, Dubai, UAE</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Phone className="w-5 h-5 flex-shrink-0 text-gold-500" />
                <span>+91 88489 95170</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Mail className="w-5 h-5 flex-shrink-0 text-gold-500" />
                <span>hello@zahiyafashion.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-xs">
            &copy; {new Date().getFullYear()} ZAHIYA Fashion. All rights reserved.
          </p>
          <div className="flex gap-4 text-gray-500 text-xs">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
