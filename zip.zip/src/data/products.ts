export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  hoverImage: string;
  images: string[];
  description: string;
  isNew?: boolean;
  isTrending?: boolean;
}

export const products: Product[] = [
  {
    id: "1",
    name: "Zahiya Premium Collection - Midnight Abaya",
    price: 129.99,
    category: "Abayas",
    image: "https://images.unsplash.com/photo-1589465885857-44edb59bbff2?q=80&w=800&auto=format&fit=crop",
    hoverImage: "https://images.unsplash.com/photo-1621092892558-867138374d81?q=80&w=800&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1589465885857-44edb59bbff2?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1621092892558-867138374d81?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1596455607563-ad6193f76b17?q=80&w=800&auto=format&fit=crop"
    ],
    description: "Experience the epitome of elegance with our Midnight Abaya from the Zahiya Premium Collection. Crafted with luxurious flowing fabric, it features subtle gold embroidery that catches the light beautifully.",
    isNew: true,
    isTrending: true,
  },
  {
    id: "2",
    name: "New Arrival 2026 - Desert Rose Modest Set",
    price: 145.00,
    category: "Modest Wear",
    image: "https://images.unsplash.com/photo-1596455607563-ad6193f76b17?q=80&w=800&auto=format&fit=crop",
    hoverImage: "https://images.unsplash.com/photo-1605763240000-7e93b172d754?q=80&w=800&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1596455607563-ad6193f76b17?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1605763240000-7e93b172d754?q=80&w=800&auto=format&fit=crop"
    ],
    description: "A stunning two-piece modest set in a soft desert rose hue. Perfect for both daytime elegance and evening sophistication.",
    isNew: true,
  },
  {
    id: "3",
    name: "Zahiya Signature - Ivory Silk Kaftan",
    price: 189.50,
    category: "Elegant Fashion",
    image: "https://images.unsplash.com/photo-1605763240000-7e93b172d754?q=80&w=800&auto=format&fit=crop",
    hoverImage: "https://images.unsplash.com/photo-1589465885857-44edb59bbff2?q=80&w=800&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1605763240000-7e93b172d754?q=80&w=800&auto=format&fit=crop"
    ],
    description: "Drape yourself in luxury with our Ivory Silk Kaftan. Designed for the modern woman who values both comfort and high-end style.",
    isTrending: true,
  },
  {
    id: "4",
    name: "Emerald Green Pleated Dress",
    price: 115.00,
    category: "Modest Wear",
    image: "https://images.unsplash.com/photo-1615233500055-b71008643806?q=80&w=800&auto=format&fit=crop",
    hoverImage: "https://images.unsplash.com/photo-1589465885857-44edb59bbff2?q=80&w=800&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1615233500055-b71008643806?q=80&w=800&auto=format&fit=crop"
    ],
    description: "Rich emerald green pleated dress offering a flattering silhouette while maintaining modesty. A true statement piece.",
  },
  {
    id: "5",
    name: "Zahiya Premium Collection - Onyx Black Abaya",
    price: 135.00,
    category: "Abayas",
    image: "https://images.unsplash.com/photo-1621092892558-867138374d81?q=80&w=800&auto=format&fit=crop",
    hoverImage: "https://images.unsplash.com/photo-1596455607563-ad6193f76b17?q=80&w=800&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1621092892558-867138374d81?q=80&w=800&auto=format&fit=crop"
    ],
    description: "The classic black abaya reimagined. Featuring premium crepe fabric and subtle detailing for an understated luxury look.",
    isTrending: true,
  },
  {
    id: "6",
    name: "New Arrival 2026 - Pearl Embellished Gown",
    price: 210.00,
    category: "Elegant Fashion",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop",
    hoverImage: "https://images.unsplash.com/photo-1605763240000-7e93b172d754?q=80&w=800&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop"
    ],
    description: "Make an entrance with this breathtaking pearl-embellished gown. Designed for special occasions where elegance is paramount.",
    isNew: true,
  },
  {
    id: "7",
    name: "Zahiya Premium Collection - Sapphire Blue Tunic",
    price: 95.00,
    category: "Modest Wear",
    image: "https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?q=80&w=800&auto=format&fit=crop",
    hoverImage: "https://images.unsplash.com/photo-1615233500055-b71008643806?q=80&w=800&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?q=80&w=800&auto=format&fit=crop"
    ],
    description: "A versatile sapphire blue tunic that pairs perfectly with wide-leg trousers for a chic, modest everyday look.",
  },
  {
    id: "8",
    name: "Golden Sand Flowing Abaya",
    price: 155.00,
    category: "Abayas",
    image: "https://images.unsplash.com/photo-1550614000-4b95dd2458bf?q=80&w=800&auto=format&fit=crop",
    hoverImage: "https://images.unsplash.com/photo-1589465885857-44edb59bbff2?q=80&w=800&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1550614000-4b95dd2458bf?q=80&w=800&auto=format&fit=crop"
    ],
    description: "Inspired by the desert dunes, this golden sand abaya offers a relaxed yet incredibly sophisticated silhouette.",
    isTrending: true,
  }
];
