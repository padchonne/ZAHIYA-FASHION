import { motion } from "motion/react";

export default function About() {
  return (
    <div className="bg-white min-h-screen">
      {/* Hero */}
      <section className="relative h-[60vh] min-h-[400px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?q=80&w=2000&auto=format&fit=crop" 
            alt="About Zahiya" 
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        <div className="relative z-10 text-center px-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl md:text-6xl font-serif text-white mb-4"
          >
            Our Story
          </motion.h1>
          <motion.div 
            initial={{ opacity: 0, width: 0 }}
            animate={{ opacity: 1, width: "64px" }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="h-[1px] bg-gold-400 mx-auto"
          ></motion.div>
        </div>
      </section>

      {/* Content Split */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-gold-500 uppercase tracking-widest text-sm font-medium mb-4 block">The Beginning</span>
            <h2 className="text-3xl md:text-4xl font-serif mb-6 leading-tight">Redefining Modest Luxury</h2>
            <p className="text-gray-600 leading-relaxed mb-6">
              Founded with a vision to blend contemporary fashion with timeless modesty, ZAHIYA Fashion emerged as a sanctuary for women seeking elegance without compromise. 
            </p>
            <p className="text-gray-600 leading-relaxed mb-8">
              Every piece in our collection is thoughtfully designed, meticulously crafted, and tailored to perfection. We believe that true luxury lies in the details—the drape of the fabric, the precision of the stitch, and the confidence it inspires in the wearer.
            </p>
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Signature_of_John_Hancock.svg/1200px-Signature_of_John_Hancock.svg.png" alt="Signature" className="h-12 opacity-50 filter grayscale" />
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-[4/5] overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1550614000-4b95dd2458bf?q=80&w=800&auto=format&fit=crop" 
                alt="Craftsmanship" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-8 -left-8 w-48 h-48 bg-beige-200 -z-10 hidden md:block"></div>
          </motion.div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-beige-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-serif mb-16">Our Philosophy</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { title: "Elegance", desc: "We design for the sophisticated woman who appreciates refined aesthetics and graceful silhouettes." },
              { title: "Quality", desc: "Sourcing only the finest fabrics to ensure every garment not only looks luxurious but feels exceptional." },
              { title: "Modesty", desc: "Celebrating beauty through modesty, offering designs that empower and respect personal values." }
            ].map((value, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.2 }}
                className="bg-white p-10 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="w-12 h-12 bg-black text-white flex items-center justify-center rounded-full mx-auto mb-6 font-serif text-xl">
                  {i + 1}
                </div>
                <h3 className="text-xl font-serif mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed text-sm">{value.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
