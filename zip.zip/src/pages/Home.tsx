import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowRight, Star } from "lucide-react";
import { products } from "../data/products";

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

export default function Home() {
  const trendingProducts = products.filter(p => p.isTrending).slice(0, 4);

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-[90vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        <motion.div 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="absolute inset-0 z-0"
        >
          <img 
            src="https://images.unsplash.com/photo-1589465885857-44edb59bbff2?q=80&w=2000&auto=format&fit=crop" 
            alt="Zahiya Fashion Hero" 
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-black/30"></div>
        </motion.div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="block text-gold-400 font-sans tracking-[0.2em] uppercase text-sm md:text-base mb-4"
          >
            New Arrival 2026
          </motion.span>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-5xl md:text-7xl lg:text-8xl font-serif text-white mb-6 leading-tight"
          >
            Elegance in <br className="hidden md:block" /> Every Stitch
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-gray-200 text-lg md:text-xl mb-10 max-w-2xl mx-auto font-light"
          >
            Discover our premium collection of modest wear and abayas, designed for the modern woman.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Link 
              to="/shop" 
              className="inline-flex items-center justify-center px-8 py-4 bg-white text-black font-medium uppercase tracking-wider text-sm hover:bg-gold-500 hover:text-white transition-all duration-300 group"
            >
              Shop Collection
              <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeUp}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-serif mb-4">Curated Collections</h2>
            <div className="w-16 h-[1px] bg-gold-500 mx-auto"></div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Premium Abayas", image: "https://images.unsplash.com/photo-1621092892558-867138374d81?q=80&w=800&auto=format&fit=crop" },
              { title: "Modest Sets", image: "https://images.unsplash.com/photo-1596455607563-ad6193f76b17?q=80&w=800&auto=format&fit=crop" },
              { title: "Evening Elegance", image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop" }
            ].map((cat, index) => (
              <motion.div 
                key={index}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
                variants={fadeUp}
                className="group relative h-[500px] overflow-hidden cursor-pointer"
              >
                <img 
                  src={cat.image} 
                  alt={cat.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-80"></div>
                <div className="absolute bottom-0 left-0 w-full p-8 translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  <h3 className="text-2xl font-serif text-white mb-2">{cat.title}</h3>
                  <Link to="/shop" className="text-gold-400 text-sm uppercase tracking-wider font-medium flex items-center opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                    Explore <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Products */}
      <section className="py-24 bg-beige-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeUp}
            className="flex justify-between items-end mb-12"
          >
            <div>
              <h2 className="text-3xl md:text-4xl font-serif mb-4">Trending Now</h2>
              <div className="w-16 h-[1px] bg-gold-500"></div>
            </div>
            <Link to="/shop" className="hidden md:flex items-center text-sm uppercase tracking-wider font-medium hover:text-gold-500 transition-colors">
              View All <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </motion.div>

          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12"
          >
            {trendingProducts.map((product) => (
              <motion.div key={product.id} variants={fadeUp} className="group">
                <Link to={`/product/${product.id}`} className="block relative overflow-hidden mb-4 aspect-[3/4] bg-gray-100">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="absolute inset-0 w-full h-full object-cover object-center transition-opacity duration-500 group-hover:opacity-0"
                  />
                  <img 
                    src={product.hoverImage} 
                    alt={`${product.name} alternate`} 
                    className="absolute inset-0 w-full h-full object-cover object-center opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                  />
                  {product.isNew && (
                    <span className="absolute top-4 left-4 bg-white text-black text-xs font-bold uppercase tracking-wider px-2 py-1">
                      New
                    </span>
                  )}
                  <div className="absolute bottom-0 left-0 w-full p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <button className="w-full bg-black/90 backdrop-blur-sm text-white py-3 text-sm uppercase tracking-wider hover:bg-gold-500 transition-colors">
                      Quick View
                    </button>
                  </div>
                </Link>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">{product.category}</p>
                  <h3 className="font-serif text-lg mb-2 group-hover:text-gold-600 transition-colors line-clamp-1">
                    <Link to={`/product/${product.id}`}>{product.name}</Link>
                  </h3>
                  <p className="font-medium">${product.price.toFixed(2)}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
          
          <div className="mt-12 text-center md:hidden">
            <Link to="/shop" className="inline-flex items-center text-sm uppercase tracking-wider font-medium border-b border-black pb-1 hover:text-gold-500 hover:border-gold-500 transition-colors">
              View All Collection
            </Link>
          </div>
        </div>
      </section>

      {/* Limited Time Offer */}
      <section className="py-24 bg-black text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-40">
          <img src="https://images.unsplash.com/photo-1605763240000-7e93b172d754?q=80&w=2000&auto=format&fit=crop" alt="Background" className="w-full h-full object-cover" />
        </div>
        <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
          >
            <span className="text-gold-400 uppercase tracking-[0.2em] text-sm font-medium mb-4 block">Limited Time Offer</span>
            <h2 className="text-4xl md:text-6xl font-serif mb-6">Ramadan Exclusive</h2>
            <p className="text-gray-300 text-lg mb-10 max-w-2xl mx-auto">
              Enjoy complimentary worldwide shipping and a special gift with every order from our new Zahiya Premium Collection.
            </p>
            <Link to="/shop" className="inline-block border border-white px-8 py-4 uppercase tracking-wider text-sm hover:bg-white hover:text-black transition-colors">
              Discover More
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-serif mb-4">Client Testimonials</h2>
            <div className="w-16 h-[1px] bg-gold-500 mx-auto"></div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: "Aisha M.", text: "The quality of the Midnight Abaya is unmatched. It flows beautifully and the embroidery is so delicate. Truly a luxury piece." },
              { name: "Fatima R.", text: "I ordered the Desert Rose set for an event and received so many compliments. The fabric feels incredibly premium." },
              { name: "Sarah K.", text: "Zahiya Fashion has become my go-to for elegant modest wear. Their customer service via WhatsApp was also exceptional." }
            ].map((review, i) => (
              <motion.div 
                key={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
                variants={fadeUp}
                className="bg-beige-100 p-8 text-center"
              >
                <div className="flex justify-center gap-1 mb-6 text-gold-500">
                  {[...Array(5)].map((_, j) => <Star key={j} className="w-4 h-4 fill-current" />)}
                </div>
                <p className="text-gray-600 italic mb-6 leading-relaxed">"{review.text}"</p>
                <p className="font-serif font-medium">{review.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Instagram Feed */}
      <section className="py-12 bg-beige-100">
        <div className="text-center mb-10">
          <h2 className="text-2xl font-serif mb-2">@ZahiyaFashion</h2>
          <p className="text-gray-500 text-sm">Follow us on Instagram</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-1">
          {[
            "https://images.unsplash.com/photo-1589465885857-44edb59bbff2?q=80&w=400&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1596455607563-ad6193f76b17?q=80&w=400&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1605763240000-7e93b172d754?q=80&w=400&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1621092892558-867138374d81?q=80&w=400&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1615233500055-b71008643806?q=80&w=400&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=400&auto=format&fit=crop"
          ].map((img, i) => (
            <a key={i} href="#" className="relative group aspect-square overflow-hidden block">
              <img src={img} alt="Instagram post" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <Instagram className="text-white w-6 h-6" />
              </div>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}

// Need to import Instagram icon
import { Instagram } from "lucide-react";
