import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { Filter, ChevronDown } from "lucide-react";
import { products } from "../data/products";

export default function Shop() {
  const [activeCategory, setActiveCategory] = useState("All");

  const categories = ["All", "Abayas", "Modest Wear", "Elegant Fashion"];

  const filteredProducts = activeCategory === "All" 
    ? products 
    : products.filter(p => p.category === activeCategory);

  return (
    <div className="bg-white min-h-screen pt-12 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-serif mb-4">The Collection</h1>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Explore our meticulously crafted pieces, designed to bring elegance and modesty to your everyday wardrobe.
          </p>
        </div>

        {/* Filters & Controls */}
        <div className="flex flex-col md:flex-row justify-between items-center border-b border-gray-200 pb-6 mb-12 gap-6">
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto no-scrollbar pb-2 md:pb-0">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`whitespace-nowrap px-4 py-2 text-sm uppercase tracking-wider transition-colors ${
                  activeCategory === cat 
                    ? "bg-black text-white" 
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
            <button className="flex items-center gap-2 text-sm uppercase tracking-wider font-medium hover:text-gold-500 transition-colors">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 text-sm uppercase tracking-wider font-medium hover:text-gold-500 transition-colors">
              Sort By <ChevronDown className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-10 md:gap-x-8 md:gap-y-16">
          {filteredProducts.map((product, index) => (
            <motion.div 
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group"
            >
              <Link to={`/product/${product.id}`} className="block relative overflow-hidden mb-4 aspect-[3/4] bg-gray-100">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="absolute inset-0 w-full h-full object-cover object-center transition-opacity duration-500 group-hover:opacity-0"
                />
                <img 
                  src={product.hoverImage} 
                  alt={`${product.name} alternate`} 
                  className="absolute inset-0 w-full h-full object-cover object-center opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                />
                {product.isNew && (
                  <span className="absolute top-3 left-3 bg-white text-black text-[10px] md:text-xs font-bold uppercase tracking-wider px-2 py-1">
                    New
                  </span>
                )}
                <div className="absolute bottom-0 left-0 w-full p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 hidden md:block">
                  <button className="w-full bg-black/90 backdrop-blur-sm text-white py-3 text-sm uppercase tracking-wider hover:bg-gold-500 transition-colors">
                    Quick View
                  </button>
                </div>
              </Link>
              <div>
                <p className="text-[10px] md:text-xs text-gray-500 uppercase tracking-wider mb-1">{product.category}</p>
                <h3 className="font-serif text-sm md:text-lg mb-1 md:mb-2 group-hover:text-gold-600 transition-colors line-clamp-2 md:line-clamp-1">
                  <Link to={`/product/${product.id}`}>{product.name}</Link>
                </h3>
                <p className="font-medium text-sm md:text-base">${product.price.toFixed(2)}</p>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </div>
  );
}
