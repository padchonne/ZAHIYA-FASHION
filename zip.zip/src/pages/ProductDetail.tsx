import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "motion/react";
import { ShoppingBag, Heart, Share2, ChevronRight, MessageCircle } from "lucide-react";
import { products } from "../data/products";

export default function ProductDetail() {
  const { id } = useParams();
  const product = products.find(p => p.id === id) || products[0];
  const [mainImage, setMainImage] = useState(product.images[0]);
  const [selectedSize, setSelectedSize] = useState("M");

  const sizes = ["XS", "S", "M", "L", "XL"];

  const whatsappMessage = `Hello ZAHIYA! I would like to order: ${product.name} (Size: ${selectedSize}) - $${product.price}`;
  const whatsappUrl = `https://wa.me/918848995170?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="bg-white min-h-screen pt-8 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-xs uppercase tracking-wider text-gray-500 mb-8">
          <Link to="/" className="hover:text-black transition-colors">Home</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to="/shop" className="hover:text-black transition-colors">Shop</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-black">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20">
          
          {/* Image Gallery */}
          <div className="flex flex-col-reverse md:flex-row gap-4">
            <div className="flex md:flex-col gap-4 overflow-x-auto md:overflow-visible no-scrollbar w-full md:w-24 flex-shrink-0">
              {product.images.map((img, idx) => (
                <button 
                  key={idx}
                  onClick={() => setMainImage(img)}
                  className={`relative aspect-[3/4] w-20 md:w-full flex-shrink-0 overflow-hidden border-2 transition-colors ${mainImage === img ? 'border-gold-500' : 'border-transparent'}`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
            <div className="relative aspect-[3/4] w-full bg-gray-100 overflow-hidden group">
              <motion.img 
                key={mainImage}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                src={mainImage} 
                alt={product.name} 
                className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-110 cursor-zoom-in"
              />
            </div>
          </div>

          {/* Product Info */}
          <div className="flex flex-col pt-4 md:pt-10">
            <p className="text-sm text-gold-600 uppercase tracking-wider font-medium mb-2">{product.category}</p>
            <h1 className="text-3xl md:text-4xl font-serif mb-4">{product.name}</h1>
            <p className="text-2xl font-medium mb-8">${product.price.toFixed(2)}</p>
            
            <p className="text-gray-600 leading-relaxed mb-8">
              {product.description}
            </p>

            {/* Size Selector */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm uppercase tracking-wider font-medium">Size</span>
                <button className="text-xs text-gray-500 underline hover:text-black">Size Guide</button>
              </div>
              <div className="flex flex-wrap gap-3">
                {sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-12 h-12 flex items-center justify-center border text-sm transition-colors ${
                      selectedSize === size 
                        ? "border-black bg-black text-white" 
                        : "border-gray-300 hover:border-black text-gray-700"
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col gap-4 mb-10">
              <button className="w-full bg-black text-white py-4 uppercase tracking-wider text-sm font-medium hover:bg-gray-900 transition-colors flex items-center justify-center gap-2">
                <ShoppingBag className="w-5 h-5" /> Add to Cart
              </button>
              
              <a 
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-green-500 text-white py-4 uppercase tracking-wider text-sm font-medium hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5" /> Order via WhatsApp
              </a>
            </div>

            {/* Details Accordion (Simplified) */}
            <div className="border-t border-gray-200 pt-6 space-y-4">
              <div className="flex justify-between items-center cursor-pointer group">
                <span className="text-sm uppercase tracking-wider font-medium group-hover:text-gold-500 transition-colors">Fabric & Care</span>
                <span className="text-xl font-light">+</span>
              </div>
              <div className="flex justify-between items-center cursor-pointer group">
                <span className="text-sm uppercase tracking-wider font-medium group-hover:text-gold-500 transition-colors">Shipping & Returns</span>
                <span className="text-xl font-light">+</span>
              </div>
            </div>

            {/* Share & Wishlist */}
            <div className="flex items-center gap-6 mt-10 pt-6 border-t border-gray-200">
              <button className="flex items-center gap-2 text-sm text-gray-500 hover:text-black transition-colors">
                <Heart className="w-4 h-4" /> Add to Wishlist
              </button>
              <button className="flex items-center gap-2 text-sm text-gray-500 hover:text-black transition-colors">
                <Share2 className="w-4 h-4" /> Share
              </button>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
