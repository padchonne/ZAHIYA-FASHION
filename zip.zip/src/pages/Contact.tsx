import { motion } from "motion/react";
import { MapPin, Phone, Mail, MessageCircle } from "lucide-react";

export default function Contact() {
  return (
    <div className="bg-white min-h-screen pt-12 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-serif mb-4">Get in Touch</h1>
          <p className="text-gray-500 max-w-2xl mx-auto">
            We're here to assist you. Whether you have a question about our collections, sizing, or an existing order, our team is ready to help.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-beige-100 p-8 md:p-12"
          >
            <h2 className="text-2xl font-serif mb-8">Send us a Message</h2>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2">First Name</label>
                  <input type="text" className="w-full bg-transparent border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors" />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2">Last Name</label>
                  <input type="text" className="w-full bg-transparent border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors" />
                </div>
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2">Email Address</label>
                <input type="email" className="w-full bg-transparent border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors" />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2">Message</label>
                <textarea rows={4} className="w-full bg-transparent border-b border-gray-300 py-2 focus:outline-none focus:border-black transition-colors resize-none"></textarea>
              </div>
              <button type="button" className="bg-black text-white px-8 py-4 uppercase tracking-wider text-sm font-medium hover:bg-gray-900 transition-colors w-full md:w-auto">
                Send Message
              </button>
            </form>
          </motion.div>

          {/* Contact Info & Map */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col justify-between"
          >
            <div className="mb-12">
              <h2 className="text-2xl font-serif mb-8">Contact Information</h2>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-beige-200 rounded-full flex items-center justify-center flex-shrink-0 text-gold-600">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Boutique Location</h3>
                    <p className="text-gray-500 text-sm">123 Fashion Avenue, Dubai Design District<br />Dubai, UAE</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-beige-200 rounded-full flex items-center justify-center flex-shrink-0 text-gold-600">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Phone</h3>
                    <p className="text-gray-500 text-sm">+91 88489 95170</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-beige-200 rounded-full flex items-center justify-center flex-shrink-0 text-gold-600">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Email</h3>
                    <p className="text-gray-500 text-sm">hello@zahiyafashion.com</p>
                  </div>
                </div>
              </div>
            </div>

            {/* WhatsApp Direct */}
            <div className="bg-green-50 p-8 border border-green-100 mb-8">
              <h3 className="font-serif text-xl mb-2 text-green-900">Need immediate assistance?</h3>
              <p className="text-green-700 text-sm mb-6">Our styling team is available on WhatsApp to help you with sizing, styling advice, and orders.</p>
              <a 
                href="https://wa.me/918848995170" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-500 text-white px-6 py-3 rounded-full hover:bg-green-600 transition-colors font-medium text-sm"
              >
                <MessageCircle className="w-5 h-5" /> Chat with us
              </a>
            </div>

            {/* Map Placeholder */}
            <div className="w-full h-48 bg-gray-200 relative overflow-hidden group">
              <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=800&auto=format&fit=crop" alt="Map" className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="bg-black text-white px-4 py-2 text-xs uppercase tracking-wider font-medium">View on Google Maps</span>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </div>
  );
}
